'use client'

import Invoice from '@/sections/invoice/view/invoice'

export default function HomePage() {
    return <Invoice />
}
