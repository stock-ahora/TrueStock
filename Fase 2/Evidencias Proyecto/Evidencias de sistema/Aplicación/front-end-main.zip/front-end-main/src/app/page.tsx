'use client'

import DashboardSelector from '@/sections/dashboard/view/dashboard'

export default function HomePage() {
    return <DashboardSelector />
}
