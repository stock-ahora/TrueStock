'use client'

import ReportsPage from '@/sections/reports/view/reports'

export default function HomePage() {
    return <ReportsPage />
}
