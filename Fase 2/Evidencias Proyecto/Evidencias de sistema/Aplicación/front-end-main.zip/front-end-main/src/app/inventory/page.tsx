'use client'

import InventoryPage from '@/sections/inventory/view/inventory'

export default function HomePage() {
    return <InventoryPage />
}
