'use client'

import PredictiveModelView from '@/sections/predictive-model/view/predectiveModel'

export default function PredictiveModelPage() {
    return <PredictiveModelView />
}
