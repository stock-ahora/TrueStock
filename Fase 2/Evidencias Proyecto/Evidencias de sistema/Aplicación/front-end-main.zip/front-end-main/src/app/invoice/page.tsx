'use client'

import InvoiceList from '@/sections/invoice/view/invoiceList'

export default function InvoiceListPage() {
    return <InvoiceList />
}
