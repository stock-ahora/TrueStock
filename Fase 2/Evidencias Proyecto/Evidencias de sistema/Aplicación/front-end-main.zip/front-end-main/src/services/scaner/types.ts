export type Scanner = {
    id: string | number
    type: 'in' | 'out'

    status: 'Activo' | 'Inactivo'
}
