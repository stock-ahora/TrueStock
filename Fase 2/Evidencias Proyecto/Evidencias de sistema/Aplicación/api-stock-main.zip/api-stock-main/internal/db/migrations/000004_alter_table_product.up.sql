ALTER TABLE product RENAME COLUMN "clientAccount" TO client_account_id;
