CREATE table if not exists notification (
    message varchar(1000) not null,
    type varchar(100) not null
)