package bedrock

const CLAUDE_SONE_V3 = "anthropic.claude-3-haiku-20240307-v1:0"
const NOVA_LITE_AWS = "amazon.nova-lite-v1:0"
const NOVA_PRO_AWS = "amazon.nova-pro-v1:0"
